/**
* Copyright 2022 by the authors (see AUTHORS).
*
* Goéland is an automated theorem prover for first order logic.
*
* This software is governed by the CeCILL license under French law and
* abiding by the rules of distribution of free software.  You can  use,
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info".
*
* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability.
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or
* data to be ensured and,  more generally, to use and operate it in the
* same conditions as regards security.
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
**/

/**
* This file contains functions and types common to destructive and non-destructive version of tableaux and the search algorithm
**/

package Search

import (
	"fmt"

	"github.com/GoelandProver/Goeland/AST"
	"github.com/GoelandProver/Goeland/Core"
	"github.com/GoelandProver/Goeland/Glob"
	"github.com/GoelandProver/Goeland/Lib"
	"github.com/GoelandProver/Goeland/Unif"
)

type SearchAlgorithm interface {
	Search(AST.Form, int) bool
	SetApplyRules(func(uint64, State, Communication, Core.FormAndTermsList, int, int, []int))
	ManageClosureRule(uint64, *State, Communication, Lib.List[Lib.List[Unif.MixedSubstitution]], Core.FormAndTerms, int, int) (bool, []Core.SubstAndForm)
}

var UsedSearch SearchAlgorithm

var EagerEq = false

var debug Glob.Debugger

func InitDebugger() {
	debug = Glob.CreateDebugger("search")
}

func init() {
	SetSearchAlgorithm(NewDestructiveSearch())
}

func SetSearchAlgorithm(algo SearchAlgorithm) {
	UsedSearch = algo
}

func SetApplyRules(function func(uint64, State, Communication, Core.FormAndTermsList, int, int, []int)) {
	UsedSearch.SetApplyRules(function)
}

/* Begin the proof search */
func Search(formula AST.Form, bound int) {
	debug(Lib.MkLazy(func() string { return "Start search" }))
	debug(
		Lib.MkLazy(func() string { return fmt.Sprintf("Initial formula: %v", formula.ToString()) }),
	)

	UsedSearch.Search(formula, bound)
}

func PrintSearchResult(res bool) {
	Glob.PrintInfo("Res", fmt.Sprintf("%v goroutines created", Glob.GetNbGoroutines()))
	Glob.PrintInfo("Res", "==== Result ====")

	validity := ""
	status := ""

	if res {
		validity = "VALID"

		if Glob.IsConjectureFound() {
			status = "Theorem"
		} else {
			status = "Unsatisfiable"
		}
	} else {
		validity = "NOT VALID"

		if Glob.IsConjectureFound() {
			status = "CounterSatisfiable"
		} else {
			status = "Satisfiable"
		}
	}

	Glob.PrintInfo("MAIN", fmt.Sprintf("%v RES : %v", "%", validity))
	printStandardSolution(status)
}

// Do not change this function, it is the standard output for TPTP files
func printStandardSolution(status string) {
	fmt.Printf("%s SZS status %v for %v\n", "%", status, Glob.GetProblemName())
}

func retrieveMetaFromSubst(substs Lib.List[Unif.MixedSubstitution]) []int {
	res := []int{}
	for _, subst := range substs.GetSlice() {
		switch s := subst.Substitution().(type) {
		case Lib.Some[Unif.Substitution]:
			res = Glob.AppendIfNotContainsInt(res, s.Val.Key().GetFormula())
		}
	}
	return res
}
