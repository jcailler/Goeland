/**
* Copyright 2022 by the authors (see AUTHORS).
*
* Goéland is an automated theorem prover for first order logic.
*
* This software is governed by the CeCILL license under French law and
* abiding by the rules of distribution of free software.  You can  use,
* modify and/ or redistribute the software under the terms of the CeCILL
* license as circulated by CEA, CNRS and INRIA at the following URL
* "http://www.cecill.info".
*
* As a counterpart to the access to the source code and  rights to copy,
* modify and redistribute granted by the license, users are provided only
* with a limited warranty  and the software's author,  the holder of the
* economic rights,  and the successive licensors  have only  limited
* liability.
*
* In this respect, the user's attention is drawn to the risks associated
* with loading,  using,  modifying and/or developing or reproducing the
* software by the user in light of its specific status of free software,
* that may mean  that it is complicated to manipulate,  and  that  also
* therefore means  that it is reserved for developers  and  experienced
* professionals having in-depth computer knowledge. Users are therefore
* encouraged to load and test the software's suitability as regards their
* requirements in conditions enabling the security of their systems and/or
* data to be ensured and,  more generally, to use and operate it in the
* same conditions as regards security.
*
* The fact that you are presently reading this means that you have had
* knowledge of the CeCILL license and that you accept its terms.
**/

/**
* This file contains functions and types which describe the term's data structure
**/

package AST

import (
	"github.com/GoelandProver/Goeland/Lib"
)

/* Term */
type Term interface {
	Lib.Comparable
	Lib.Stringable
	Lib.Copyable[Term]
	GetIndex() int
	GetName() string
	IsMeta() bool
	IsFun() bool
	ToMeta() Meta
	GetMetas() Lib.Set[Meta]
	GetMetaList() Lib.List[Meta] // Metas appearing in the term ORDERED
	GetSubTerms() Lib.List[Term]
	ReplaceSubTermBy(original_term, new_term Term) Term
	SubstTy(old TyGenVar, new Ty) Term
	Less(any) bool
}

/*** Makers ***/
func MakeId(i int, s string) Id {
	return Id{i, s}
}

func MakeQuotedId(i int, s string) Id {
	return Id{i, "" + s + "'"}
}

func MakeVar(i int, s string) Var {
	return Var{i, s}
}

func MakeMeta(index, occurence int, s string, f int, ty Ty) Meta {
	return Meta{index, occurence, s, f, ty}
}

func MakeFun(p Id, ty_args Lib.List[Ty], args Lib.List[Term], metas Lib.Set[Meta]) Fun {
	return Fun{p, ty_args, args, Lib.MkCache(metas, Fun.forceGetMetas)}
}

/*** Functions **/

func TermEquals(x, y Term) bool {
	return x.Equals(y)
}
